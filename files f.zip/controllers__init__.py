# -*- coding: utf-8 -*-
# Part of Odoo Real Estate Module

from . import property_search_controller
